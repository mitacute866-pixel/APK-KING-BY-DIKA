package com.apkkingbydika.launcher

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

private val Bg = Color(0xFF101014)
private val CardBg = Color(0xFF202027)
private val Accent = Color(0xFFE53935)
private val Soft = Color(0xFFBDBDC7)

data class StoredItem(val name: String, val file: File)

class MainActivity : ComponentActivity() {
    private val libraryDir by lazy { File(filesDir, "minecraft_library").apply { mkdirs() } }
    private var importKind = "pack"
    private var importCallback: ((String) -> Unit)? = null

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importSelected(uri)
    }
    private val backupCreator = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) createBackup(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            KingV2(
                itemsProvider = { listItems() },
                launchGame = { launchMinecraft() },
                importWorld = { pickFile("world") },
                importPack = { pickFile("pack") },
                backup = { backupCreator.launch("APK_KING_backup.zip") },
                openItem = { openImported(it) },
                deleteItem = { deleteImported(it) }
            )
        }
    }

    private fun pickFile(kind: String) {
        importKind = kind
        val mime = arrayOf("*/*")
        picker.launch(mime)
    }

    private fun importSelected(uri: Uri) {
        val name = queryName(uri) ?: "import_${System.currentTimeMillis()}"
        val lower = name.lowercase()
        val valid = if (importKind == "world")
            lower.endsWith(".mcworld") || lower.endsWith(".zip")
        else lower.endsWith(".mcpack") || lower.endsWith(".mcaddon") || lower.endsWith(".zip")
        if (!valid) {
            Toast.makeText(this, "Pilih file .mcworld, .mcpack, .mcaddon, atau .zip", Toast.LENGTH_LONG).show()
            return
        }
        try {
            val safeName = name.replace(Regex("[^A-Za-z0-9._ -]"), "_")
            val prefix = if (importKind == "world") "World_" else "Pack_"
            val dest = File(libraryDir, prefix + safeName)
            contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(dest).use { output -> input.copyTo(output) }
            } ?: throw Exception("File tidak bisa dibaca")
            Toast.makeText(this, "Tersimpan di Library: ${dest.name}", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal mengimpor: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun queryName(uri: Uri): String? {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0)
        }
        return uri.lastPathSegment
    }

    private fun listItems(): List<StoredItem> =
        libraryDir.listFiles()?.filter { it.isFile }?.sortedByDescending { it.lastModified() }
            ?.map { StoredItem(it.name, it) } ?: emptyList()

    private fun launchMinecraft() {
        val intent = packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
        if (intent == null) Toast.makeText(this, "Minecraft Bedrock belum terpasang.", Toast.LENGTH_LONG).show()
        else startActivity(intent)
    }

    private fun openImported(item: StoredItem) {
        val uri = androidx.core.content.FileProvider.getUriForFile(
            this, "$packageName.fileprovider", item.file
        )
        val view = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/octet-stream")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(Intent.createChooser(view, "Buka dengan"))
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "Tidak ada aplikasi yang bisa membuka file ini.", Toast.LENGTH_LONG).show()
        }
    }

    private fun deleteImported(item: StoredItem) {
        if (item.file.delete()) Toast.makeText(this, "File dihapus", Toast.LENGTH_SHORT).show()
    }

    private fun createBackup(uri: Uri) {
        try {
            contentResolver.openOutputStream(uri)?.use { raw ->
                ZipOutputStream(raw).use { zip ->
                    libraryDir.listFiles()?.filter { it.isFile }?.forEach { file ->
                        zip.putNextEntry(ZipEntry(file.name))
                        FileInputStream(file).use { it.copyTo(zip) }
                        zip.closeEntry()
                    }
                }
            }
            Toast.makeText(this, "Backup Library berhasil dibuat.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Backup gagal: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}

@Composable
fun KingV2(
    itemsProvider: () -> List<StoredItem>,
    launchGame: () -> Unit,
    importWorld: () -> Unit,
    importPack: () -> Unit,
    backup: () -> Unit,
    openItem: (StoredItem) -> Unit,
    deleteItem: (StoredItem) -> Unit
) {
    var tab by remember { mutableStateOf(0) }
    var refresh by remember { mutableIntStateOf(0) }
    val items = remember(tab, refresh) { itemsProvider() }

    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = CardBg)) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = CardBg) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 },
                        icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1; refresh++ },
                        icon = { Icon(Icons.Default.Folder, null) }, label = { Text("Library") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 },
                        icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Settings") })
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().background(Bg).padding(padding).padding(18.dp)) {
                Text("👑 APK KING", color = Accent, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text("BY DIKA", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black)
                Text("FULL EDITION • v2.0", color = Soft, fontSize = 12.sp)
                Spacer(Modifier.height(18.dp))
                when (tab) {
                    0 -> {
                        Card(colors = CardDefaults.cardColors(containerColor = CardBg),
                            shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(18.dp)) {
                                Text("WELCOME, KING!", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                Text("Launcher dan library pendamping Minecraft Bedrock.", color = Soft)
                                Spacer(Modifier.height(14.dp))
                                Button(onClick = launchGame, colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
                                    Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("LAUNCH MINECRAFT")
                                }
                            }
                        }
                        Spacer(Modifier.height(14.dp))
                        ActionButton("Import World (.mcworld)", Icons.Default.Public, importWorld)
                        ActionButton("Import Resource / Skin Pack", Icons.Default.Inventory2, importPack)
                        ActionButton("Backup Library ke ZIP", Icons.Default.Backup, backup)
                        Text("File yang diimpor disimpan di ruang aplikasi APK KING.", color = Soft, fontSize = 11.sp)
                    }
                    1 -> {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("MY LIBRARY", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            TextButton(onClick = { refresh++ }) { Text("Refresh", color = Accent) }
                        }
                        if (items.isEmpty()) Text("Belum ada file. Impor world atau pack dari Home.", color = Soft)
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(items, key = { it.file.absolutePath }) { item ->
                                Card(colors = CardDefaults.cardColors(containerColor = CardBg),
                                    shape = RoundedCornerShape(12.dp)) {
                                    Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Column(Modifier.weight(1f)) {
                                            Text(item.name, color = Color.White, fontWeight = FontWeight.SemiBold)
                                            Text("${item.file.length() / 1024} KB", color = Soft, fontSize = 11.sp)
                                        }
                                        TextButton(onClick = { openItem(item) }) { Text("Open", color = Accent) }
                                        TextButton(onClick = { deleteItem(item); refresh++ }) { Text("Delete", color = Soft) }
                                    }
                                }
                            }
                        }
                    }
                    else -> {
                        Text("SETTINGS", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        Text("APK KING BY DIKA • v2.0", color = Soft)
                        Text("Tema Black / Red", color = Soft)
                        Text("Library disimpan di penyimpanan privat aplikasi.", color = Soft)
                        Text("Aplikasi ini tidak membuka Flarial+ dan tidak menyertakan Minecraft. Minecraft harus sudah terpasang secara resmi.", color = Soft)
                    }
                }
            }
        }
    }
}

@Composable
private fun ActionButton(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, action: () -> Unit) {
    Card(onClick = action, colors = CardDefaults.cardColors(containerColor = CardBg),
        shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(icon, null, tint = Accent)
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
        }
    }
}
