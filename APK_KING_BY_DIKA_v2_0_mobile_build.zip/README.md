# APK KING BY DIKA v2.0 — build from Android phone

This source package includes a GitHub Actions workflow to build a debug APK in the cloud.

## Build from your Android phone
1. Sign in to GitHub and create a new repository. Choose Public or Private.
2. Upload the contents of this ZIP after extracting it. The repository root must contain `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, `app/`, and `.github/`.
3. Open the repository's Actions tab.
4. Select **Build APK KING BY DIKA**, then tap **Run workflow**.
5. Wait for the workflow to finish with a green check.
6. Open the completed workflow run, scroll to **Artifacts**, and download `APK-KING-BY-DIKA-v2.0`.
7. Extract the downloaded artifact ZIP; install `app-debug.apk` on your phone. Allow installation from that browser/file manager if Android asks.

## Notes
- This produces a debug APK, not a Play Store release.
- Minecraft must be installed separately from an authorized source.
- The app's current import stores `.mcworld` / `.mcpack` files in its private library. It does not guarantee automatic installation into Minecraft.
- The build needs internet access and a GitHub account.
